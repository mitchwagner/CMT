import sys
from readability.readability import Document
import re
from bs4 import BeautifulSoup
import avro
import avro.schema
from avro.datafile import DataFileWriter
from avro.io import DatumWriter
from urlparse import urlparse
from langdetect import detect_langs
import uuid
import time
import csv
import glob

__undefined_collection__ = 'undefined collection'

Webpage_collection = { 'z700': 'wdbj7 shooting' }

# Load Profanity word list
with open('profanity_en.txt') as f:
    __profanity_words__ = f.read()[:-1].split('\n')

# Clean extra blank spaces in webpage text
def cleanblankspaces( clean_content0 ):
    clean_content = clean_content0
    clean_content = re.sub(' . ', '. ', clean_content)
    clean_content = re.sub(' (,|;) ', ', ', clean_content)
    clean_content = re.sub(' +', ' ', clean_content)
    clean_content = re.sub('^ +| +$', '', clean_content)
    return clean_content

def webcontentcleanup( content ):
    URL_regexp = re.compile( r'https?://[a-zA-Z0-9\./-]+' )
    
    ProfanityRegexp = re.compile(
        r'(?<=^|(?<=[^a-zA-Z0-9-\.]))(' # Non word character starting
        + '|'.join(__profanity_words__) # Profanity word list
        + r')(?=$|\W)', re.IGNORECASE ) # End with string end or non word character
    
    url_list = re.findall( URL_regexp, content )
    for url in url_list:
        content = content.replace( url , '' )
        
    clean_content_profanity = re.sub( ProfanityRegexp , '{"profanity"}', content )
    
    clean_content_profanity = cleanblankspaces( clean_content_profanity )
    
    clean_content = re.sub( r'([^\s\w]|_)+', '', content )
    clean_content = cleanblankspaces( clean_content )
    
    # Build URL list string split by '|'
    url_list_str = '|'.join(url_list)
    return ( clean_content, clean_content_profanity , url_list_str )

def avrocleaning( filename1, filename2, collection_name ):
    try:
        InFile = open( filename1, 'r' )
        OutFile = open( filename2, 'a' )
    except IOError:
        print 'please check the filenames in arguments'
        return 0
    
    if collection_name == None:
        collection_name = __undefined_collection__
        
    # Load all text from the input file
    raw_text_all = InFile.read().decode('utf8')
    InFile.close()
    
    writer = csv.writer( OutFile, delimiter='\t' )
    
    # Each webpage record with tweet id
    regex_record_with_webpage = re.compile( 
        '\d{1,3}-\d{18}\thttps?://[a-zA-Z0-9\./-]+:URL:<!DOCTYPE.*?</html>' , re.DOTALL )
 
    # Each raw webpage record
    regex_raw_webpage = re.compile( '<!DOCTYPE.*?</html>' , re.DOTALL )
    
    # URL for this webpage
    regex_url = re.compile( r'https?://[a-zA-Z0-9\./-]+(?=:URL:<!DOCTYPE)' )
    
    # Tweet_id for this webpage
    regex_tid = re.compile( r'\d{1,3}-\d{18}' )
    
    webpage_records = re.findall( regex_record_with_webpage , raw_text_all )
    
    clean_webpage_count = 0
    languageAll = {}
    
    for raw_record in webpage_records:
        # Get the tweet id for this webpage
        if re.findall( regex_tid, raw_record ):
            tweet_id = re.findall( regex_tid, raw_record )[0]
        else:
            tweet_id = ""
        
        # Fetch URL for this webpage
        URL = re.findall( regex_url, raw_record )[0].strip()
        
        # Get raw webpage text
        raw_webpage = re.findall( regex_raw_webpage , raw_record )[0]
        
        # Get readable texts and title
        readable_article = Document( raw_webpage ).summary()
        readable_title = Document( raw_webpage ).short_title()
        
        # Replace non-ascii characters with white space in title
        readable_title = ''.join( [ char if ord( char ) < 128 else ' ' for char in readable_title] )

        URL = URL.decode( "utf8" )
        
        # Replace multiple space with one space
        readable_title = re.sub(' +', ' ', readable_title)
        
        # Get all the readable texts in the webpage
        soup = BeautifulSoup( readable_article, 'lxml' )
        texts = soup.findAll( text=True )
        all_text = ' '.join(texts).strip()
        
        # Detect the language and continue if not English
        try:
            lan = str( detect_langs( all_text )[0] ).split(':')[0]
        except:
            continue
        if lan not in languageAll:
            languageAll[lan] = 1
        else:
            languageAll[lan] += 1
        if lan != 'en':
            continue
        
        # Delete extra whitespaces 
        all_text = all_text.replace('\r\n', ' ')
        all_text = all_text.replace('\n', ' ')
        all_text = all_text.replace('\t', ' ')
        
        # Replace non-ascii characters with whitespace
        all_text = ''.join([ word if ord( word ) < 128 else ' ' for word in all_text])
        all_text = re.sub(' +', ' ', all_text)
        
        # Replace profanity words with "profanity" and get URL_list
        ( clean_content , clean_content_profanity , url_list_str ) = webcontentcleanup( all_text )
        
        domain = '{uri.netloc}'.format( uri = urlparse( URL ) )
        webpage_id = str( uuid.uuid3(uuid.NAMESPACE_DNS, URL.encode('ascii', 'ignore')) )
        
        OutputRecord = [ tweet_id, URL , domain, collection_name, webpage_id, 'en', readable_title.encode('utf-8'), clean_content.encode('utf-8'), clean_content_profanity.encode('utf-8'), url_list_str, raw_webpage.encode('utf-8') ]
        
        writer.writerow( OutputRecord )
        clean_webpage_count += 1
        
    OutFile.close()
    print filename1 + ' has been cleaned up'
    print 'Total webpages: %d' % len( webpage_records )
    print 'Cleaned webpages: %d' % clean_webpage_count
    #print 'Percentage cleaned: %.3f' % ( 100.0*clean_webpage_count / len( webpage_records ) )
    print 'Language Statitics: ', languageAll
    return 1

# Main function to take parameters from terminal
def main(argv):
    
    for table in Webpage_collection.keys():
        
        print 'Cleaning Webpage table:', table
        
        doc_collection = Webpage_collection[ table ]
        path = 'webpage-share/' + table + 'Webpages/'
        
        Files = glob.glob( path + 'part-*' )
        OutputFile = 'webpage-clean/' + table + '-clean'
        
        for filename in Files:
            avrocleaning( filename , OutputFile, doc_collection )
    
    return 1

if __name__ == '__main__':
    
    start_time = time.time()
    main( sys.argv )
    print("--- %s seconds ---\n\n\n" % ( time.time() - start_time) )
    sys.exit( 0 )
